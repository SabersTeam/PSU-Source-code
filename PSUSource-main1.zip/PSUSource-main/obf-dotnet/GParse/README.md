# GParse
A recursive descent parser framework

Documentation is a WIP.
See [my calculator](https://github.com/GGG-KILLER/Calculator) for an usage example.
