﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo ( "GParse.Tests" )]
