--[[--------------------------------------------------------------------

  test_optlex.lua: Tests for optlex.lua
  This file is part of LuaSrcDiet.

  Copyright (c) 2008 Kein-Hong Man <khman@users.sf.net>
  The COPYRIGHT file describes the conditions
  under which this software may be distributed.

  See the ChangeLog for more information.

----------------------------------------------------------------------]]

--[[--------------------------------------------------------------------
-- NOTES:
-- * To test, run it like this:
--     lua5.1 test_optlex.lua
----------------------------------------------------------------------]]

------------------------------------------------------------------------
--
------------------------------------------------------------------------
